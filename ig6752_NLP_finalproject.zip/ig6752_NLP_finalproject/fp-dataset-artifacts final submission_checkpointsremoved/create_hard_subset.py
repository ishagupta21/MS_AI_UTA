import datasets
from transformers import AutoTokenizer, AutoModelForSequenceClassification, Trainer
import torch
from helpers import prepare_dataset_nli
import numpy as np

def main():
    # 1. Load your "Detective" (Hypothesis-Only) Model
    model_path = "./model_hypothesis_only"  # Make sure this path is correct
    print(f"Loading Blind Model from {model_path}...")
    
    tokenizer = AutoTokenizer.from_pretrained(model_path)
    model = AutoModelForSequenceClassification.from_pretrained(model_path)
    
    # 2. Load the original SNLI training data
    dataset = datasets.load_dataset("snli", split="train")
    dataset = dataset.filter(lambda ex: ex['label'] != -1) # Remove garbage
    
    # Optional: Shrink dataset for speed if you are in a rush (e.g., first 50k)
    # dataset = dataset.select(range(50000)) 

    # 3. Preprocess for the Blind Model (Remove Premises!)
    def prepare_blind(exs):
        exs['premise'] = [""] * len(exs['premise']) # BLIND IT
        return prepare_dataset_nli(exs, tokenizer, 128)
    
    print("Preprocessing training data for inspection...")
    dataset_featurized = dataset.map(
        prepare_blind, 
        batched=True, 
        remove_columns=dataset.column_names
    )

    # 4. Get Predictions from the Blind Model
    print("Running inference to find artifacts...")
    trainer = Trainer(model=model)
    logits = trainer.predict(dataset_featurized).predictions
    preds = np.argmax(logits, axis=-1)
    
    # 5. Filter: Keep ONLY examples where the Blind Model FAILED
    # If Blind Model matches Label -> It's an Artifact (Throw away)
    # If Blind Model != Label      -> It's Hard (Keep)
    
    labels = np.array(dataset['label'])
    # logic: keep where predictions are WRONG
    is_hard = (preds != labels) 
    
    # Filter the original raw dataset
    hard_dataset = dataset.select(np.where(is_hard)[0])
    
    print("\n" + "="*40)
    print(f"Original Size: {len(dataset)}")
    print(f"Hard Subset Size: {len(hard_dataset)}")
    print(f"Artifacts Removed: {len(dataset) - len(hard_dataset)}")
    print("="*40 + "\n")
    
    # 6. Save to disk (JSONL format matches your run.py)
    print("Saving hard_snli_train.jsonl...")
    hard_dataset.to_json("hard_snli_train.jsonl")
    print("Done!")

if __name__ == "__main__":
    main()

