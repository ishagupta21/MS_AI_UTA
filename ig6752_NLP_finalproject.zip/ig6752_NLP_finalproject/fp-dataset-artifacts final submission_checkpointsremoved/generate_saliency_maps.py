import transformers
import torch
import numpy as np
import os

# Try to import matplotlib, but make it optional
try:
    import matplotlib.pyplot as plt
    from matplotlib.colors import LinearSegmentedColormap
    HAS_MATPLOTLIB = True
except ImportError:
    HAS_MATPLOTLIB = False
    print("Warning: matplotlib not available. Will generate text-only saliency maps.")

def compute_integrated_gradients(model, tokenizer, premise, hypothesis, target_label=None, n_steps=50):
    """Compute integrated gradients for token importance"""
    # Tokenize
    inputs = tokenizer(premise, hypothesis, return_tensors="pt", truncation=True, max_length=128)
    input_ids = inputs['input_ids']
    
    # Get embedding layer
    embeddings = model.get_input_embeddings()
    baseline = torch.zeros_like(embeddings(input_ids))
    
    # Get prediction
    model.eval()
    with torch.no_grad():
        outputs = model(**inputs)
        logits = outputs.logits
        if target_label is None:
            target_label = torch.argmax(logits, dim=-1)
        original_score = logits[0][target_label].item()
    
    # Compute integrated gradients
    gradients = []
    alphas = torch.linspace(0, 1, n_steps)
    
    for alpha in alphas:
        # Interpolate between baseline and actual input
        interpolated = baseline + alpha * (embeddings(input_ids) - baseline)
        interpolated.requires_grad_(True)
        
        # Forward pass
        # We need to manually compute the forward pass with interpolated embeddings
        # This is model-specific, so we'll use a simpler gradient-based approach
        pass
    
    # Simpler approach: use gradients directly
    embeddings(input_ids).requires_grad_(True)
    outputs = model(inputs_embeds=embeddings(input_ids), attention_mask=inputs['attention_mask'], token_type_ids=inputs.get('token_type_ids'))
    logits = outputs.logits
    score = logits[0][target_label]
    score.backward()
    
    # Get gradients
    grad = embeddings.weight.grad if hasattr(embeddings.weight, 'grad') and embeddings.weight.grad is not None else None
    
    if grad is None:
        # Fallback: use attention or simple gradient
        input_ids.requires_grad_(True)
        outputs = model(input_ids=input_ids, attention_mask=inputs['attention_mask'], token_type_ids=inputs.get('token_type_ids'))
        logits = outputs.logits
        score = logits[0][target_label]
        score.backward()
        
        # Get token embeddings and their gradients
        token_embeddings = embeddings(input_ids)
        # Approximate importance by embedding norm changes
        importance = torch.norm(token_embeddings, dim=-1).squeeze()
    else:
        # Use gradient magnitude
        token_grads = grad[input_ids.squeeze()]
        importance = torch.norm(token_grads, dim=-1)
    
    return importance.detach().cpu().numpy(), input_ids, original_score, target_label.item()

def generate_saliency_map(model_path, model_name, test_cases, output_dir="saliency_maps"):
    """Generate saliency maps for given test cases using gradient-based methods"""
    os.makedirs(output_dir, exist_ok=True)
    
    print(f"Loading {model_name} from {model_path}...")
    tokenizer = transformers.AutoTokenizer.from_pretrained(model_path)
    model = transformers.AutoModelForSequenceClassification.from_pretrained(model_path)
    model.eval()
    
    label_names = ["Entailment", "Neutral", "Contradiction"]
    
    print(f"\n{'='*60}")
    print(f"Generating Saliency Maps for {model_name}")
    print(f"{'='*60}\n")
    
    results = []
    
    for i, (premise, hypothesis, description) in enumerate(test_cases):
        print(f"Test Case {i+1}: {description}")
        print(f"Premise: {premise}")
        print(f"Hypothesis: {hypothesis}")
        
        try:
            # Get prediction first
            inputs = tokenizer(premise, hypothesis, return_tensors="pt", truncation=True, max_length=128)
            with torch.no_grad():
                outputs = model(**inputs)
                logits = outputs.logits
                probs = torch.nn.functional.softmax(logits, dim=-1)
                pred_label = torch.argmax(logits, dim=-1).item()
                pred_prob = probs[0][pred_label].item()
            
            print(f"Prediction: {label_names[pred_label]} (confidence: {pred_prob:.3f})")
            
            # Compute token importance using gradients
            input_ids = inputs['input_ids'].clone()
            
            # Get embeddings
            embeddings = model.get_input_embeddings()
            token_embeddings = embeddings(input_ids)
            token_embeddings.retain_grad()  # Retain gradient for non-leaf tensor
            
            # Forward pass with embeddings
            outputs = model(inputs_embeds=token_embeddings,
                          attention_mask=inputs['attention_mask'],
                          token_type_ids=inputs.get('token_type_ids'))
            logits = outputs.logits
            score = logits[0][pred_label]
            
            # Backward pass
            score.backward()
            
            # Get gradients
            if token_embeddings.grad is not None:
                # Compute importance as gradient magnitude
                importance = torch.abs(token_embeddings.grad).sum(dim=-1).squeeze()
            else:
                # Fallback: try to get attention weights
                try:
                    # Re-run to get attention
                    model.config.output_attentions = True
                    outputs = model(input_ids=input_ids,
                                  attention_mask=inputs['attention_mask'],
                                  token_type_ids=inputs.get('token_type_ids'))
                    if hasattr(outputs, 'attentions') and outputs.attentions is not None:
                        # Use attention from last layer, CLS token attention to all tokens
                        attention = outputs.attentions[-1][0].mean(dim=1).squeeze()  # Average over heads
                        importance = attention[0]  # CLS token attention to all tokens
                    else:
                        importance = torch.ones(input_ids.shape[1])
                    model.config.output_attentions = False
                except:
                    # Final fallback: uniform importance
                    importance = torch.ones(input_ids.shape[1])
            
            importance = importance.detach().cpu().numpy()
            tokens = tokenizer.convert_ids_to_tokens(input_ids.squeeze().cpu())
            
            # Normalize importance
            importance = (importance - importance.min()) / (importance.max() - importance.min() + 1e-8)
            
            # Find where [SEP] token is (needed for both visualization and text output)
            sep_idx = None
            for idx, token in enumerate(tokens):
                if token == '[SEP]':
                    sep_idx = idx
                    break
            
            # Create visualization if matplotlib is available
            output_file = None
            if HAS_MATPLOTLIB:
                try:
                    fig, ax = plt.subplots(figsize=(14, 6))
                    
                    # Create color map
                    colors = ['#ffcccc', '#ff0000']  # Light red to dark red
                    n_bins = 100
                    cmap = LinearSegmentedColormap.from_list('reds', colors, N=n_bins)
                    
                    # Plot importance
                    y_pos = np.arange(len(tokens))
                    bars = ax.barh(y_pos, importance, color=cmap(importance))
                    
                    # Add token labels
                    ax.set_yticks(y_pos)
                    ax.set_yticklabels(tokens, fontsize=8)
                    ax.set_xlabel('Importance Score', fontsize=10)
                    ax.set_title(f'{model_name} - {description}\n'
                                f'Prediction: {label_names[pred_label]} ({pred_prob:.3f})\n'
                                f'Premise: {premise}\n'
                                f'Hypothesis: {hypothesis}',
                                fontsize=10, pad=20)
                    ax.invert_yaxis()
                    
                    if sep_idx:
                        ax.axhline(y=sep_idx, color='blue', linestyle='--', linewidth=2, alpha=0.5, label='Premise/Hypothesis boundary')
                        ax.legend()
                    
                    plt.tight_layout()
                    output_file = os.path.join(output_dir, f"{model_name.replace(' ', '_').replace('/', '_')}_case_{i+1}.png")
                    plt.savefig(output_file, dpi=150, bbox_inches='tight')
                    plt.close()
                    print(f"  Saved visualization to {output_file}")
                except Exception as e:
                    print(f"  Could not generate visualization: {e}")
                    output_file = None
            
            # Also save text summary
            text_output = f"Saliency Analysis for {model_name} - Case {i+1}\n"
            text_output += "="*60 + "\n"
            text_output += f"Description: {description}\n"
            text_output += f"Premise: {premise}\n"
            text_output += f"Hypothesis: {hypothesis}\n"
            text_output += f"Prediction: {label_names[pred_label]} (confidence: {pred_prob:.3f})\n\n"
            text_output += "Top 15 Most Important Tokens:\n"
            text_output += "-"*60 + "\n"
            
            # Get top tokens
            top_indices = np.argsort(importance)[::-1][:15]
            for rank, idx in enumerate(top_indices, 1):
                if idx < len(tokens):
                    token_type = "Premise" if (sep_idx is None or idx < sep_idx) else "Hypothesis"
                    text_output += f"{rank:2d}. [{token_type:10s}] {tokens[idx]:15s} (importance: {importance[idx]:.4f})\n"
            
            text_file = os.path.join(output_dir, f"{model_name.replace(' ', '_').replace('/', '_')}_case_{i+1}.txt")
            with open(text_file, 'w') as f:
                f.write(text_output)
            print(f"  Saved text analysis to {text_file}\n")
            
            results.append({
                "case": i+1,
                "description": description,
                "premise": premise,
                "hypothesis": hypothesis,
                "prediction": label_names[pred_label],
                "confidence": pred_prob,
                "output_file": output_file,
                "text_file": text_file
            })
            
        except Exception as e:
            print(f"  Error: {e}")
            import traceback
            traceback.print_exc()
            print()
    
    return results


if __name__ == "__main__":
    # Test cases based on top words for each label
    # Top words in ENTAILMENT: [('people', 26700), ('outside', 14646), ('there', 14430), ('men', 8795), ('an', 7957)]
    # Top words in NEUTRAL:    [('for', 17438), ('people', 17297), ('his', 15287), ('her', 9053), ('men', 9027)]
    # Top words in CONTRADICTION: [('people', 16908), ('sitting', 9967), ('his', 9939), ('men', 9707), ('girl', 8938)]
    
    test_cases = [
        # ENTAILMENT artifact tests
        (
            "People are outside.",
            "There are people outside.",
            "ENTAILMENT Artifact Test - 'people' + 'outside' + 'there'"
        ),
        (
            "Men are working.",
            "An man is working.",
            "ENTAILMENT Artifact Test - 'men' + 'an'"
        ),
        (
            "There are people in the park.",
            "People are in the park.",
            "ENTAILMENT Artifact Test - 'there' + 'people'"
        ),
        # NEUTRAL artifact tests
        (
            "A man is working for his company.",
            "A man is working for her company.",
            "NEUTRAL Artifact Test - 'for' + 'his' + 'her'"
        ),
        (
            "People are talking.",
            "Men are talking.",
            "NEUTRAL Artifact Test - 'people' vs 'men'"
        ),
        (
            "The boy is playing for his team.",
            "The girl is playing for her team.",
            "NEUTRAL Artifact Test - 'for' + 'his' + 'her'"
        ),
        # CONTRADICTION artifact tests
        (
            "A man is standing.",
            "A man is sitting.",
            "CONTRADICTION Artifact Test - 'sitting' keyword"
        ),
        (
            "People are outside.",
            "People are sitting inside.",
            "CONTRADICTION Artifact Test - 'people' + 'sitting'"
        ),
        (
            "A boy is playing.",
            "A girl is playing.",
            "CONTRADICTION Artifact Test - 'girl' keyword (should be neutral actually)"
        ),
        (
            "His car is red.",
            "His car is blue.",
            "CONTRADICTION Artifact Test - 'his' keyword"
        ),
        (
            "Men are working.",
            "Men are sitting.",
            "CONTRADICTION Artifact Test - 'men' + 'sitting'"
        )
    ]
    
    # Generate saliency maps for both models
    print("="*60)
    print("SALIENCY MAP GENERATION")
    print("="*60)
    
    baseline_results = generate_saliency_map(
        "./model_baseline",
        "Baseline Model",
        test_cases
    )
    
    mitigated_results = generate_saliency_map(
        "./model_hard_retrained",
        "Mitigated Model",
        test_cases
    )
    
    print("\n" + "="*60)
    print("SUMMARY")
    print("="*60)
    print(f"Generated saliency maps for {len(test_cases)} test cases")
    print(f"Results saved in 'saliency_maps/' directory")
    print("="*60)

