import datasets
from collections import Counter
import re

# Load SNLI
dataset = datasets.load_dataset("snli", split="train")

def get_top_words(label_id):
    # Get all hypothesis sentences for this label (0=Entailment, 1=Neutral, 2=Contradiction)
    sentences = [x['hypothesis'] for x in dataset if x['label'] == label_id]
    text = " ".join(sentences).lower()
    # Simple cleanup
    text = re.sub(r'[^\w\s]', '', text)
    words = text.split()
    # Filter common stop words
    stop_words = {'a','the','in','of','on','are','is','man','woman','person','to','and','at','with','two','playing'}
    words = [w for w in words if w not in stop_words]
    return Counter(words).most_common(5)

print("Top words in ENTAILMENT:", get_top_words(0))
print("Top words in NEUTRAL:   ", get_top_words(1))
print("Top words in CONTRADICTION:", get_top_words(2))