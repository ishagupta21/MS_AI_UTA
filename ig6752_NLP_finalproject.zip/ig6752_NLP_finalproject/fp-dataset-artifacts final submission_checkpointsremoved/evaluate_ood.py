import datasets
import os
import json
from transformers import AutoTokenizer, AutoModelForSequenceClassification, Trainer
from helpers import prepare_dataset_nli, compute_accuracy


def evaluate_on_mnli(model_path, model_name, max_length=128):
    print(f"\n{'='*40}")
    print(f"Testing {model_name} on MultiNLI (Out-of-Distribution)...")
    print(f"{'='*40}")

    # 1. Load Model
    tokenizer = AutoTokenizer.from_pretrained(model_path)
    model = AutoModelForSequenceClassification.from_pretrained(model_path)

    # 2. Load MNLI (Matched Validation Set)
    # MNLI is harder and from different genres (fiction, government, slate, etc.)
    eval_dataset = datasets.load_dataset("glue", "mnli", split="validation_matched")
    
    # Remove examples with no label (similar to SNLI preprocessing)
    eval_dataset = eval_dataset.filter(lambda ex: ex['label'] != -1)
    
    # 3. Preprocess MNLI to look like SNLI
    def prepare_eval(exs):
        return prepare_dataset_nli(exs, tokenizer, max_length)

    print("Preprocessing MNLI dataset...")
    eval_dataset_featurized = eval_dataset.map(
        prepare_eval, 
        batched=True, 
        remove_columns=eval_dataset.column_names
    )

    # 4. Evaluate
    trainer = Trainer(
        model=model,
        compute_metrics=compute_accuracy
    )
    
    print("Running evaluation...")
    results = trainer.predict(eval_dataset_featurized)
    accuracy = results.metrics['test_accuracy']
    print(f"--> Accuracy on MNLI: {accuracy:.4f} ({accuracy*100:.2f}%)")
    
    # 5. Save results separately (MNLI-specific files)
    os.makedirs(model_path, exist_ok=True)
    
    # Save metrics
    metrics_file = os.path.join(model_path, 'mnli_eval_metrics.json')
    with open(metrics_file, 'w', encoding='utf-8') as f:
        json.dump(results.metrics, f, indent=2)
    print(f"--> Saved metrics to {metrics_file}")
    
    # Save predictions
    predictions_file = os.path.join(model_path, 'mnli_eval_predictions.jsonl')
    with open(predictions_file, 'w', encoding='utf-8') as f:
        for i, example in enumerate(eval_dataset):
            example_with_prediction = dict(example)
            example_with_prediction['predicted_scores'] = results.predictions[i].tolist()
            example_with_prediction['predicted_label'] = int(results.predictions[i].argmax())
            f.write(json.dumps(example_with_prediction))
            f.write('\n')
    print(f"--> Saved predictions to {predictions_file}")
    
    return accuracy, results.metrics


if __name__ == "__main__":
    # Compare your two best models
    baseline_acc, baseline_metrics = evaluate_on_mnli("./model_baseline", "Standard Baseline")
    mitigated_acc, mitigated_metrics = evaluate_on_mnli("./model_hard_retrained", "Mitigated Model")

    print(f"\n{'='*60}")
    print(f"FINAL COMPARISON ON MNLI (Out-of-Distribution):")
    print(f"{'='*60}")
    print(f"Baseline:  {baseline_acc*100:.2f}%")
    print(f"Mitigated: {mitigated_acc*100:.2f}%")
    print(f"Difference: {(mitigated_acc - baseline_acc)*100:+.2f}%")
    print(f"{'='*60}\n")
    
    # Save comparison summary
    comparison = {
        "dataset": "MNLI (validation_matched)",
        "evaluation_type": "Out-of-Distribution Generalization",
        "baseline_model": "./model_baseline",
        "mitigated_model": "./model_hard_retrained",
        "baseline_accuracy": baseline_acc,
        "mitigated_accuracy": mitigated_acc,
        "accuracy_difference": mitigated_acc - baseline_acc,
        "baseline_metrics": baseline_metrics,
        "mitigated_metrics": mitigated_metrics
    }
    
    comparison_file = "mnli_comparison.json"
    with open(comparison_file, 'w', encoding='utf-8') as f:
        json.dump(comparison, f, indent=2)
    print(f"Saved comparison summary to {comparison_file}")

